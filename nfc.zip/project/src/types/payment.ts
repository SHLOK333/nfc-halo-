export interface Transaction {
  id: string;
  amount: number;
  timestamp: Date;
  status: 'pending' | 'completed' | 'failed';
  merchantId: string;
  customerId: string;
  currency: string;
}

export interface Wallet {
  id: string;
  balance: number;
  currency: string;
  transactions: Transaction[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  wallet: Wallet;
}