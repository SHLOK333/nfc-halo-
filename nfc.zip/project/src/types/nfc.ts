export interface NFCTag {
  id: string;
  walletId: string | null;
  lastScan: Date | null;
  isRegistered: boolean;
}

export interface NFCCredentials {
  publicKey: string;
  privateKey: string;
  createdAt: Date;
}