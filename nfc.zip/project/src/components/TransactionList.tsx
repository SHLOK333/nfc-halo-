import React from 'react';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { Transaction } from '../types/payment';
import { formatCurrency } from '../utils/payment';

interface TransactionListProps {
  transactions: Transaction[];
}

export const TransactionList: React.FC<TransactionListProps> = ({ transactions }) => {
  return (
    <div className="w-full max-w-2xl">
      <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div
            key={transaction.id}
            className="bg-white rounded-lg p-4 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-4">
              <div className={`p-2 rounded-full ${
                transaction.status === 'completed' 
                  ? 'bg-green-100' 
                  : transaction.status === 'failed'
                  ? 'bg-red-100'
                  : 'bg-yellow-100'
              }`}>
                {transaction.status === 'completed' ? (
                  <ArrowUpRight className="w-6 h-6 text-green-600" />
                ) : (
                  <ArrowDownRight className="w-6 h-6 text-red-600" />
                )}
              </div>
              <div>
                <p className="font-medium">Payment {transaction.status}</p>
                <p className="text-sm text-gray-500">
                  {new Date(transaction.timestamp).toLocaleDateString()}
                </p>
              </div>
            </div>
            <p className={`font-semibold ${
              transaction.status === 'completed' 
                ? 'text-green-600' 
                : 'text-red-600'
            }`}>
              {formatCurrency(transaction.amount)}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};