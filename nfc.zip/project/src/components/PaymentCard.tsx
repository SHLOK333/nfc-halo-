import React from 'react';
import { CreditCard, Wallet, Nfc } from 'lucide-react';
import { formatCurrency } from '../utils/payment';

interface PaymentCardProps {
  balance: number;
  lastFour?: string;
  onTap?: () => void;
}

export const PaymentCard: React.FC<PaymentCardProps> = ({
  balance,
  lastFour = '4242',
  onTap
}) => {
  return (
    <div 
      onClick={onTap}
      className="group relative w-96 h-56 rounded-2xl p-8 text-white shadow-xl transform transition-all duration-500 hover:scale-105 cursor-pointer overflow-hidden"
    >
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-blue-500 to-blue-400 transition-transform duration-700 group-hover:scale-110" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full transform translate-x-32 -translate-y-32" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-black opacity-5 rounded-full transform -translate-x-32 translate-y-32" />

      {/* Card Content */}
      <div className="relative">
        <div className="absolute top-0 right-0 flex items-center gap-2">
          <div className="p-2 bg-white bg-opacity-20 rounded-lg">
            <Wallet className="w-6 h-6" />
          </div>
          <div className="p-2 bg-white bg-opacity-20 rounded-lg animate-pulse">
            <Nfc className="w-6 h-6" />
          </div>
        </div>

        <div className="flex flex-col h-full justify-between">
          <div>
            <p className="text-sm opacity-80">Available Balance</p>
            <p className="text-4xl font-bold mt-2">{formatCurrency(balance)}</p>
          </div>

          <div className="mt-12">
            <div className="flex items-center gap-3">
              <CreditCard className="w-6 h-6" />
              <p className="text-lg font-medium tracking-wider">•••• {lastFour}</p>
            </div>
            <div className="mt-4 flex items-center gap-2 text-sm opacity-80">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <p>Tap to make payment</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};