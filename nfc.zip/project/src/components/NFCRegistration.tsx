import React, { useState, useEffect } from 'react';
import { Scan, ShieldCheck, AlertCircle, Smartphone, CreditCard, Loader2 } from 'lucide-react';
import { scanNFCTag, generateNFCCredentials, isNFCSupported } from '../utils/nfc';
import type { NFCTag } from '../types/nfc';

interface NFCRegistrationProps {
  onRegister: (tag: NFCTag) => void;
}

export const NFCRegistration: React.FC<NFCRegistrationProps> = ({ onRegister }) => {
  const [status, setStatus] = useState<'idle' | 'preparing' | 'scanning' | 'connecting' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState(0);

  useEffect(() => {
    let progressInterval: NodeJS.Timeout;
    
    if (status === 'scanning') {
      progressInterval = setInterval(() => {
        setScanProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 1;
        });
      }, 50);
    }

    return () => {
      if (progressInterval) clearInterval(progressInterval);
    };
  }, [status]);

  const handleScan = async () => {
    if (!isNFCSupported()) {
      setError('NFC is not supported on this device');
      return;
    }

    try {
      setStatus('preparing');
      setError(null);
      setScanProgress(0);
      
      // Simulate preparing NFC reader
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setStatus('scanning');

      const tagId = await scanNFCTag();
      setStatus('connecting');
      
      const credentials = await generateNFCCredentials();
      setScanProgress(100);
      
      const newTag: NFCTag = {
        id: tagId,
        walletId: null,
        lastScan: new Date(),
        isRegistered: true
      };
      
      setTimeout(() => onRegister(newTag), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to scan NFC tag');
      setStatus('error');
      setScanProgress(0);
    }
  };

  const renderStatusMessage = () => {
    switch (status) {
      case 'preparing':
        return 'Initializing NFC reader...';
      case 'scanning':
        return 'Hold your NFC tag near your device';
      case 'connecting':
        return 'Establishing secure connection...';
      case 'error':
        return 'Scanning failed. Please try again.';
      default:
        return 'Tap the button below to start scanning';
    }
  };

  const isScanning = ['preparing', 'scanning', 'connecting'].includes(status);

  return (
    <div className="relative w-full max-w-md mx-auto">
      <div className={`bg-gradient-to-br from-blue-600 to-blue-400 rounded-2xl p-8 shadow-xl transform transition-all duration-500 ${isScanning ? 'scale-105' : 'scale-100'}`}>
        {/* Phone and NFC Animation Container */}
        <div className="relative h-64 mb-8">
          {/* Phone */}
          <div className={`absolute inset-0 flex items-center justify-center transition-all duration-700 ${
            status === 'scanning' ? 'translate-y-[-1rem]' : 'translate-y-0'
          }`}>
            <div className="relative">
              <Smartphone className="w-32 h-32 text-white" />
              {status === 'scanning' && (
                <>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-24 h-24 border-4 border-white rounded-full animate-ping opacity-75" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-20 h-20 border-4 border-white rounded-full animate-pulse opacity-50" />
                  </div>
                </>
              )}
            </div>
          </div>

          {/* NFC Card */}
          <div className={`absolute inset-0 flex items-center justify-center transition-all duration-700 ${
            status === 'scanning' 
              ? 'opacity-100 translate-y-4 scale-100' 
              : 'opacity-0 translate-y-16 scale-90'
          }`}>
            <CreditCard 
              className={`w-24 h-24 text-white transform -rotate-12 transition-all duration-700 ${
                status === 'connecting' ? 'scale-110 opacity-50' : ''
              }`}
            />
          </div>

          {/* Connection Animation */}
          {status === 'connecting' && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-40 h-40 border-4 border-white rounded-full animate-ping opacity-30" />
            </div>
          )}
        </div>

        {/* Status and Progress */}
        <div className="text-center text-white mb-8">
          <h2 className="text-3xl font-bold mb-4">
            {status === 'idle' ? 'Ready to Scan' : 'Scanning NFC Tag'}
          </h2>
          <p className="text-blue-100">
            {renderStatusMessage()}
          </p>
        </div>

        {isScanning && (
          <div className="mb-6">
            <div className="h-2 bg-blue-300 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-300 ease-out"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={handleScan}
          disabled={isScanning}
          className={`w-full py-4 px-6 rounded-xl flex items-center justify-center gap-3 text-lg font-semibold transition-all duration-300 ${
            isScanning
              ? 'bg-blue-300 text-blue-600 cursor-wait'
              : 'bg-white text-blue-600 hover:bg-blue-50 hover:shadow-lg'
          }`}
        >
          {isScanning ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              {status === 'preparing' ? 'Preparing...' : 
               status === 'connecting' ? 'Connecting...' : 'Scanning...'}
            </>
          ) : (
            <>
              <ShieldCheck className="w-6 h-6" />
              Scan NFC Tag
            </>
          )}
        </button>

        {/* Error Message */}
        {error && (
          <div className="mt-4 flex items-center gap-2 text-white bg-red-500 bg-opacity-20 p-4 rounded-xl">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {!isNFCSupported() && (
          <p className="mt-4 text-sm text-blue-100 text-center">
            Note: NFC functionality requires a compatible device and browser
          </p>
        )}
      </div>

      {/* Background Effects */}
      <div className="absolute -top-4 -right-4 w-20 h-20 bg-blue-300 rounded-full opacity-20 blur-xl" />
      <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-blue-500 rounded-full opacity-20 blur-xl" />
    </div>
  );
};