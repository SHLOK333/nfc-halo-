import React, { useState } from 'react';
import { X, Check, Loader } from 'lucide-react';
import { User } from '../types/payment';
import { processPayment } from '../utils/payment';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  sender: User;
  receiver: User;
  amount: number;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  sender,
  receiver,
  amount
}) => {
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');

  const handlePayment = async () => {
    try {
      setStatus('processing');
      await processPayment(amount, sender, receiver);
      setStatus('success');
      setTimeout(() => {
        onClose();
        setStatus('idle');
      }, 2000);
    } catch (error) {
      setStatus('error');
      setTimeout(() => {
        setStatus('idle');
      }, 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-xl p-8 w-96 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="text-center">
          <div className="mb-6">
            {status === 'idle' && (
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto">
                <Loader className="w-8 h-8 text-blue-600 animate-spin" />
              </div>
            )}
            {status === 'processing' && (
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mx-auto">
                <Loader className="w-8 h-8 text-yellow-600 animate-spin" />
              </div>
            )}
            {status === 'success' && (
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                <Check className="w-8 h-8 text-green-600" />
              </div>
            )}
            {status === 'error' && (
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto">
                <X className="w-8 h-8 text-red-600" />
              </div>
            )}
          </div>

          <h3 className="text-xl font-semibold mb-2">
            {status === 'idle' && 'Confirm Payment'}
            {status === 'processing' && 'Processing Payment...'}
            {status === 'success' && 'Payment Successful!'}
            {status === 'error' && 'Payment Failed'}
          </h3>

          <p className="text-gray-600 mb-6">
            {status === 'idle' && `Are you sure you want to send $${amount.toFixed(2)}?`}
            {status === 'processing' && 'Please wait while we process your payment'}
            {status === 'success' && 'Your payment has been processed successfully'}
            {status === 'error' && 'There was an error processing your payment'}
          </p>

          {status === 'idle' && (
            <div className="flex gap-4">
              <button
                onClick={onClose}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handlePayment}
                className="flex-1 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Confirm
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};