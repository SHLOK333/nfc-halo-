import React, { useState } from 'react';
import { PaymentCard } from './components/PaymentCard';
import { TransactionList } from './components/TransactionList';
import { PaymentModal } from './components/PaymentModal';
import { NFCRegistration } from './components/NFCRegistration';
import { User, Transaction } from './types/payment';
import { NFCTag } from './types/nfc';

// Mock data
const mockUser: User = {
  id: '1',
  name: 'John Doe',
  email: 'john@example.com',
  wallet: {
    id: 'w1',
    balance: 1500.00,
    currency: 'USD',
    transactions: []
  }
};

const mockMerchant: User = {
  id: '2',
  name: 'Coffee Shop',
  email: 'shop@example.com',
  wallet: {
    id: 'w2',
    balance: 5000.00,
    currency: 'USD',
    transactions: []
  }
};

const mockTransactions: Transaction[] = [
  {
    id: '1',
    amount: 25.99,
    timestamp: new Date('2024-03-10'),
    status: 'completed',
    merchantId: '2',
    customerId: '1',
    currency: 'USD'
  },
  {
    id: '2',
    amount: 49.99,
    timestamp: new Date('2024-03-09'),
    status: 'completed',
    merchantId: '2',
    customerId: '1',
    currency: 'USD'
  },
  {
    id: '3',
    amount: 15.00,
    timestamp: new Date('2024-03-08'),
    status: 'failed',
    merchantId: '2',
    customerId: '1',
    currency: 'USD'
  }
];

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [paymentAmount] = useState(35.99);
  const [registeredTag, setRegisteredTag] = useState<NFCTag | null>(null);

  const handleNFCRegister = (tag: NFCTag) => {
    const tagWithWallet = {
      ...tag,
      walletId: mockUser.wallet.id
    };
    setRegisteredTag(tagWithWallet);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Secure Payment System
          </h1>
          <p className="text-lg text-gray-600">
            {registeredTag 
              ? 'Your NFC tag is connected and ready for payments'
              : 'Connect your NFC tag to get started'}
          </p>
        </div>

        <div className="flex flex-col items-center gap-12">
          {!registeredTag ? (
            <NFCRegistration onRegister={handleNFCRegister} />
          ) : (
            <>
              <PaymentCard
                balance={mockUser.wallet.balance}
                onTap={() => setIsModalOpen(true)}
              />
              <TransactionList transactions={mockTransactions} />
            </>
          )}

          <PaymentModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            sender={mockUser}
            receiver={mockMerchant}
            amount={paymentAmount}
          />
        </div>
      </div>
    </div>
  );
}

export default App;