import { Transaction, User } from '../types/payment';

export const generateTransactionId = (): string => {
  return Math.random().toString(36).substring(2, 15);
};

export const formatCurrency = (amount: number, currency: string = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
};

export const processPayment = async (
  amount: number,
  sender: User,
  receiver: User
): Promise<Transaction> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  if (sender.wallet.balance < amount) {
    throw new Error('Insufficient funds');
  }

  const transaction: Transaction = {
    id: generateTransactionId(),
    amount,
    timestamp: new Date(),
    status: 'completed',
    merchantId: receiver.id,
    customerId: sender.id,
    currency: 'USD'
  };

  return transaction;
};