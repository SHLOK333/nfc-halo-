import type { NFCCredentials } from '../types/nfc';

export const isNFCSupported = (): boolean => {
  return 'NDEFReader' in window;
};

export const generateNFCCredentials = async (): Promise<NFCCredentials> => {
  // Simulate generating secure credentials
  await new Promise(resolve => setTimeout(resolve, 1500));
  return {
    publicKey: Math.random().toString(36).substring(2, 15),
    privateKey: Math.random().toString(36).substring(2, 15),
    createdAt: new Date()
  };
};

export const scanNFCTag = async (): Promise<string> => {
  if (!isNFCSupported()) {
    throw new Error('NFC is not supported on this device');
  }

  try {
    // Simulate the scanning process for development
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // In a real implementation, this would use the Web NFC API
    if ('NDEFReader' in window) {
      const ndef = new (window as any).NDEFReader();
      await ndef.scan();
      
      return new Promise((resolve) => {
        ndef.onreading = (event: any) => {
          const decoder = new TextDecoder();
          const message = decoder.decode(event.message.records[0].data);
          resolve(message);
        };
      });
    }
    
    // For development, return a mock tag ID
    return `TAG_${Math.random().toString(36).substring(2, 15)}`;
  } catch (error) {
    throw new Error('Failed to scan NFC tag. Please try again.');
  }
};